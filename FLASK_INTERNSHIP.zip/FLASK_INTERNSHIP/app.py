import numpy as np
from flask import Flask, render_template, request
import pickle

# model loading
model = pickle.load(open('flask_gb_model.pkl',"rb"))
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    age = float(request.form['age'])
    workclass = float(request.form['workclass'])
    education = float(request.form['education'])
    marital_status = float(request.form['marital_status'])
    occupation = float(request.form['occupation'])
    relationship = float(request.form['relationship'])
    race = float(request.form['race'])
    sex = float(request.form['sex'])
    hours_per_week = float(request.form['hours_per_week'])
    arr= np.array([[age, workclass,education,marital_status,occupation,relationship,race,sex,hours_per_week]])
    pred = model.predict(arr)
    if (pred==0):
        result=' <= 50K '
    else:
        result=' > 50K '
    return render_template('index.html', prediction_text=' Salary Package is - {}'.format(result))

if __name__ == "__main__":
    app.run(debug=True)
